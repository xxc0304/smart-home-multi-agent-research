# Automatic quantitative analysis

Semantic case review is pending. These are development data, not confirmation.

Complete task-seed units: 28; non-OK responses: 0.

|View|N self|P repeat public|E expert final|O ordinary finals|EO all finals|
|---|---:|---:|---:|---:|---:|
|fresh|37.50%|37.50%|37.50%|37.50%|37.50%|
|all_descriptive|37.50%|37.50%|37.50%|37.50%|37.50%|
|primary_fresh_both_seeds|37.50%|37.50%|37.50%|37.50%|37.50%|
|fresh_seed0|50.00%|50.00%|50.00%|50.00%|50.00%|
|fresh_seed1|25.00%|25.00%|25.00%|25.00%|25.00%|
