# D80 extension: COMPLETED_WITH_INCOMPLETE_TRIALS

```json
{
  "status": "COMPLETED_WITH_INCOMPLETE_TRIALS",
  "error": null,
  "expected_tasks": 80,
  "inherited_tasks": 8,
  "new_tasks_planned": 72,
  "attempted_requests": 3655,
  "confirmed_generated_returns": 3655,
  "host_records": 0,
  "max_new_calls": 3744,
  "statuses": {
    "OK": 3650,
    "OUTPUT_LIMIT": 5
  },
  "unknown": 0,
  "elapsed_seconds": 22186.521258984983,
  "no_wall_clock_cutoff": true,
  "primary_enabled": false,
  "scope": "DEVELOPMENT_NOT_CONFIRMATORY",
  "oom_cells": 0
}
```

Scores and expert/communication/readout diagnostics are stored separately at checkpoints/*/scores.json and SUMMARY.json.
