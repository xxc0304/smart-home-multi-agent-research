# V6统一1024工作上限D8对照：COMPLETE

助手自审none/provisional；非独立质量等价。实际返回832/832，尝试832，错误None。

```json
{
  "counts": {
    "serial": {
      "n_expected_tasks": 8,
      "n_complete": 8,
      "returned": 416,
      "statuses": {
        "OK": 416
      },
      "batch_response_counts": {
        "1": 416
      },
      "unknown": 0,
      "input_tokens": 1501945,
      "output_tokens": 47891
    },
    "batch2": {
      "n_expected_tasks": 8,
      "n_complete": 8,
      "returned": 416,
      "statuses": {
        "OK": 416
      },
      "batch_response_counts": {
        "2": 352,
        "1": 64
      },
      "unknown": 0,
      "input_tokens": 1497640,
      "output_tokens": 48353
    }
  },
  "seconds": {
    "serial": 2404.911577657971,
    "batch2": 2147.525490528991
  },
  "time_saved_fraction": 0.10702517694211278
}
```
